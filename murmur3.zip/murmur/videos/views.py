from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from .models import UserModel 
from .models import VideoModel
import datetime
import random
import time
import datetime
from django.core.mail import EmailMessage
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.datastructures import MultiValueDictKeyError

#dictionary for post likes and another staff
Dictionary_stat_in_project={
	'name_of_user':""
}

#dictionary for log in and get session time
Dictionary_of_data = {
	'login':"",
	'password':"",
	'time':"",
	'hoursStart':0 ,
	'hoursEnd': 0 ,
	'PasswordForFirstFactor':"",
	'PasswordCheckOfUser':""
}

def index(request):
	#####################################
	#prepare code for check of user
	result_user = ""
	if request.method == "POST":
		user = UserModel()
		user.name_of_user = request.POST.get('name_input')
		user.password_of_user =request.POST.get('password_input')
		user.email_of_user = request.POST.get('email_input')
		user.amount_of_landu_user = 0
		user.request_money = 0
		if len(request.FILES) != 0:

			user.image_of_user = request.FILES['image_input']

		user.save()
		return redirect('/')
	name = Dictionary_of_data["login"]

	return render(request,'videos/index.html',{'name':name})

def user_page(request,pk):
	user_info= UserModel.objects.filter(pk=pk)
	return render(request,'videos/user.html',{'user_info':user_info,'val':4})

def authorization(request):
	#####################################
	#prepare code for check of user
	result_user = ""
	
	authorized = False 
	if request.method == "POST":
		name_of_user_input = request.POST["name_input_a"]
		password_of_user_input = request.POST["password_input_a"]
		result_user = UserModel.objects.filter(name_of_user = name_of_user_input , password_of_user=password_of_user_input )
		Dictionary_of_data["login"] =name_of_user_input
		Dictionary_of_data["password"]=password_of_user_input	
		authorized = True
		return redirect('/')
	return render(request,'videos/auth.html',{'user':result_user,'athorized':authorized})

def send_money(request):

	if request.method == "POST":
		name_of_user_input = request.POST["name_input_s"]
		amount_of_landu_user_input = request.POST["amount_of_landu_user_s"]
		#user_id = UserModel.objects.filter(name_of_user=name_of_user_input).first()
		#pk_i =user_id["id"]
		user = UserModel.objects.get(name_of_user=name_of_user_input)
		
		user.amount_of_landu_user += int(amount_of_landu_user_input)
		user.save()
	return render(request,'videos/index.html')	
# Create your views here.
