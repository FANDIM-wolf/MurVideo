from django.contrib import admin
from .models import UserModel ,VideoModel
 
admin.site.register(UserModel)
admin.site.register(VideoModel)
# Register your models here.
