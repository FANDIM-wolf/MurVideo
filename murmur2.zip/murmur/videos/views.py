from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from .models import UserModel 
from .models import VideoModel
import datetime
import random
import time
import datetime
from django.core.mail import EmailMessage
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.datastructures import MultiValueDictKeyError

#dictionary for post likes and another staff
Dictionary_stat_in_project={
	'name_of_user':""
}

#dictionary for log in and get session time
Dictionary_of_data = {
	'login':"",
	'password':"",
	'time':"",
	'hoursStart':0 ,
	'hoursEnd': 0 ,
	'PasswordForFirstFactor':"",
	'PasswordCheckOfUser':""
}

def index(request):
	#####################################
	#prepare code for check of user
	result_user = ""
	if request.method == "POST":
        name_of_user_input = request.POST["name_input"]
        password_of_user_input = request.POST["password_input"]
        email_of_user_input = request.POST["email_input"]
	
	
	return render(request,'videos/index.html')
# Create your views here.
