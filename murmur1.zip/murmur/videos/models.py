from django.db import models

# Create your models here.
class UserModel(models.Model):
    name_of_user = models.CharField(max_length=200)
    email_of_user = models.EmailField(max_length = 254)
    password_of_user = models.CharField(max_length=50)
    image_of_user = models.ImageField(upload_to='images/')


class VideoModel(models.Model):
    name_of_video = models.CharField(max_length=200)
    user_of_video = models.ForeignKey(UserModel,on_delete=models.CASCADE)
    video_name= models.FileField(upload_to='videos/')
    pub_date = models.DateTimeField('date published')


